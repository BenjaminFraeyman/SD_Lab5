﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo5_3
{
    class Player // houd de kaarten bij + deelt kaarten uit
    {
        public List<Card> Hand = new List<Card>();
        public string Name { get; private set; }
        public Player(string naam) { Name = naam; }
        Random random = new Random();
        public void GiveCard(Card temp)
        {
            Hand.Add(temp);
        }
    }
}