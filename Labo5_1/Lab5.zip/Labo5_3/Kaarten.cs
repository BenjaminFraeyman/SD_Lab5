﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo5_3
{
    class Cards
    {
        Random random = new Random();
        public List<string> Images = new List<string>(); // plaatjes
        public List<Card> OriginalDeck = new List<Card>(); // niet willekeurig deck
        public Player Player = new Player("Player"); // speler
        public void Generate(int amount) // kaarten genereren
        {
            // aanmaken van je spel kaarten
            for (int value = 0; value < amount; value++)
            {
                for (int i = 0; i < Images.Count; i++)
                {
                    string image = Images[i];
                    Card card = new Card(image, value, false);
                    OriginalDeck.Add(card);
                }
            }
            // uitdelen van de kaarten
            while (OriginalDeck.Count != 0)
            {
                // willekeurig kaart nemen, geven aan de speler, dan verwijderen uit je spel kaarten
                int rand = random.Next(OriginalDeck.Count);
                Card temp = OriginalDeck[rand];
                Player.GiveCard(temp);
                OriginalDeck.RemoveAt(rand);
            }
            //hand per speler uitprinten
            int counter = 0;
            foreach (Card card in Player.Hand)
            {
                Console.Write(card);
                counter++;
                if (counter == 10)
                {
                    Console.WriteLine();
                    counter = 0;
                }
            }
            Console.WriteLine();
        }

        public void Round(int amount, int Correct) // wat er gebeurt in een ronde
        {
            Boolean play = true;
            while (play)
            {
                Console.WriteLine();
                for (int i = 0; i < Player.Hand.Count; i++)
                {
                    if (Player.Hand[i].Turned == true)
                    {
                        Console.Write(Player.Hand[i]); 
                    }
                    else if (Player.Hand[i].Turned == false)
                    {
                        Console.Write(i);
                    }
                    Console.Write(" ");
                }
                Console.WriteLine();
                List<Card> ChosenCards = new List<Card>();
                for (int i = 0; i < amount; i++)
                {
                    Console.WriteLine("Welke kaart wilt u draaien?");
                    int chosen = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("De kaart is: " + Player.Hand[chosen]);
                    ChosenCards.Add(Player.Hand[chosen]);
                }
                for (int i = 0; i < ChosenCards.Count; i++)
                {
                    int equals = 0;
                    List<Card> TempDeck = new List<Card>();
                    for (int j = 0; j < ChosenCards.Count; j++)
                    {
                        if (ChosenCards[i].Value == ChosenCards[j].Value)
                        {
                            equals++;
                            TempDeck.Add(ChosenCards[j]);
                        }
                    }
                    if (equals >= Correct) // als #waardes overeenkomt goed is blijven ze gedraaid
                    {
                        foreach (Card card in TempDeck)
                        {
                            card.ChangeTurned(card, true);
                        }
                    }
                }
                int count = 0;
                foreach (Card card in Player.Hand)
                {
                    if (card.Turned == true)
                    { count++; }
                }
                if (count == Player.Hand.Count) { play = false; }
            }  
            Console.WriteLine("Gewonnen");       
        }
    }
}