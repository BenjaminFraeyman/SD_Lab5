﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo5_3
{
    class Card // welke eigenschappen de kaarten bevatten
    {
        public string Image { get; private set; }
        public int Value { get; private set; }
        public bool Turned { get; private set; }
        // aanmaak van een kaartje
        public Card(string im, int val, bool turn)
        {
            Image = im;
            Value = val;
            Turned = turn;
        }
        public void ChangeTurned(Card card, bool turn) // omdraaien
        {
            card.Turned = turn;
        }
        public override string ToString() // uitprinten
        {
            return "[" + Image + "-" + Value + "]";
        }
    }
}