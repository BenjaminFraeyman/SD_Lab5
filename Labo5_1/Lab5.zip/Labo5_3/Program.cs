﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//benodigde tijd: 3h
namespace Labo5_3
{
    public class Program
    {
        public static void Main()
        {
            Cards deck = new Cards();
            Boolean Add = true;
            int ToPick = 2;
            int Equal = 2;
            while (Add)
            {
                string YesNo;
                Console.WriteLine("Een plaatje toevoegen?(ja/nee)");
                YesNo = Console.ReadLine();
                if (YesNo == "ja")
                {
                    Console.WriteLine("Welk plaatje?");
                    deck.Images.Add(Console.ReadLine());
                }
                else if (YesNo == "nee")
                {
                    if (deck.Images.Count > 1)
                    { Add = false; }
                    else { Console.WriteLine("Geef minimum 2 plaatjes op."); }
                }
            }
            Console.WriteLine("Hoeveel kaarten bestaan er per plaatje?");
            int amount = Convert.ToInt32(Console.ReadLine());
            deck.Generate(amount);
            Boolean Correctinput = true;
            while (Correctinput)
            {
                Console.WriteLine("Hoeveel kaarten kan je draaien per ronde?");
                ToPick = Convert.ToInt32(Console.ReadLine());
                if (ToPick <= deck.OriginalDeck.Count)
                {
                    Correctinput = false;
                }
                Console.WriteLine("Teveel kaarten per ronde!");
            }
            Correctinput = true;
            while (Correctinput)
            {
                Console.WriteLine("Hoeveel kaarten moeten overeenkomen?");
                Equal = Convert.ToInt32(Console.ReadLine());
                if (Equal <= ToPick)
                {
                    Correctinput = false;
                }
                Console.WriteLine("Overeenkomende is een groter aantal dan gekozene!");
            }           
            deck.Round(ToPick, Equal);
            Console.WriteLine();
        }
    }
}