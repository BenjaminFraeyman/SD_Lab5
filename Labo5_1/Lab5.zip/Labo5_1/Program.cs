﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// benodigde tijd: 15 minuten
namespace Labo5_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hallo vreemdeling. Hoe heet je?");
            string persoon = Console.ReadLine(); // string die je naam zal bevatten + ingave naam
            List<string> namen = new List<string>();
            namen.Add(persoon);
            Boolean nietalleen = true;
            while (nietalleen)
            {
                Console.WriteLine("Is er nog iemand bij je?(ja of nee)");
                string janee = Console.ReadLine();
                if (janee == "ja")
                {
                    Console.WriteLine("Hallo andere vreemdeling. Hoe heet jij?");
                    string anderepersonen = Console.ReadLine();
                    namen.Add(anderepersonen);
                }
                else if (janee == "nee") // niemand extra erbij
                {
                    nietalleen = false;
                }
            }
            Console.Write("HALLO"); // output
            int i = 0;
            foreach (string naam in namen)
            {
                if (i == 0) { Console.Write(" " + naam); }
                else { Console.Write(", " + naam); }
                i++;
            }
            Console.Write(" ! Welcome to this world.");
            Console.ReadLine();
        }
    }
}