﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// benodigde tijd: 2h (2de versie)
namespace Labo5_4b_versie2
{
    class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            int Choice = 0; // keuze van richting
            Dictionary<int, Field> Map = new Dictionary<int, Field>();
            string[] dir = new string[] { "8: Up", "2: Down", "4: Left", "6: Right", "0: Quit" }; // lijst van mogelijke richtingen
            int n = 0;
            int size = 10; // grootte van het veld
            Person Player = new Person(5, 5, 10, 2);
            Field field = new Field(size); // mainfield
            int[] Location = new int[2] { n, n };
            field.PlacePerson(Player);
            int Coords = GetHash(Location);
            Map.Add(Coords, field);
            int[] TempLoc = new int[2];
            int TempCoords = GetHash(TempLoc);
            Field Tempfield = new Field(10); // mainfield
            Boolean Running = true;

            int Vert = 0;
            int Hor = 0;
            int Death = -1;
            while (Running)
            {
                if (Death != -1)
                {
                    Console.Clear();
                    Console.WriteLine("GAME OVER - Restart? (1: Yes, 2: No)");
                    while (!int.TryParse(Console.ReadLine(), out Death) || !(Death == 1) && !(Death == 2)) // om foute input te voorkomen
                    {
                        Console.WriteLine("Invalid input!");
                    }
                    if (Death == 2) // quit
                    {
                        Running = false;
                    }
                    else if (Death == 1) 
                    {
                        Console.Clear();
                        Death = -1;
                        Vert = 0;
                        Hor = 0;
                        Map = new Dictionary<int, Field>();
                        n = 0;
                        Player = new Person(5, 5, 10, 2);
                        field = new Field(size); // mainfield
                        Location = new int[2] { n, n };
                        field.PlacePerson(Player);
                        Coords = GetHash(Location);
                        Map.Add(Coords, field);
                        TempLoc = new int[2];
                        TempCoords = GetHash(TempLoc);
                        Tempfield = new Field(10); // mainfield
                    }
                }
                
                while (Player.HP > 0)
                {
                    for (int i = Vert - 1; i <= Vert + 1; i++)
                    {
                        TempLoc[0] = i;
                        for (int j = Hor - 1; j <= Hor + 1; j++)
                        {
                            TempLoc[1] = j;
                            TempCoords = GetHash(TempLoc);
                            if (!Map.ContainsKey(TempCoords))
                            {
                                Tempfield = new Field(10);
                                Map.Add(TempCoords, Tempfield);
                            }
                        }
                    }
                    field.DisplayField(Map, Hor, Vert);
                    Console.WriteLine(n);
                    Console.WriteLine("What direction?");
                    foreach (string q in dir) // mogelijke keuzes
                    { Console.WriteLine(q); }
                    while (!int.TryParse(Console.ReadLine(), out Choice) || !(Choice == 0) && !(Choice == 4) && !(Choice == 2) && !(Choice == 8) && !(Choice == 6)) // om foute input te voorkomen
                    {
                        Console.WriteLine("Invalid input!");
                    }
                    if (Choice == 0) // quit
                    {
                        Running = false;
                    }
                    Console.Clear(); // opkuisen van console
                    field.ErasePerson(Player);
                    Player.MovePerson(Choice, field); // ventje verplaatsen naar locatie indien mogelijk
                    if (Player.X < 0)
                    {
                        Hor = Hor - 1;
                        Player.SwitchField(Choice);
                    }
                    if (Player.Y < 0)
                    {
                        Vert = Vert - 1;
                        Player.SwitchField(Choice);
                    }
                    if (Player.X == field.Width)
                    {
                        Hor = Hor + 1;
                        Player.SwitchField(Choice);
                    }

                    if (Player.Y == field.Width)
                    {
                        Vert = Vert + 1;
                        Player.SwitchField(Choice);
                    }
                    TempLoc[0] = Vert;
                    TempLoc[1] = Hor;
                    TempCoords = GetHash(TempLoc);
                    field = Map[TempCoords];
                    field.PlacePerson(Player);
                }
                Death = 0;
                
            }
        }

        public static int GetHash(int[] obj) // om de hashwaarde te verkrijgen
        {
            int result = 17;
            for (int i = 0; i < obj.Length; i++)
            {
                unchecked
                {
                    result = result * 23 + obj[i];
                }
            }
            return result;
        }
    }
}