﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo5_4b_versie2
{
    class Field
    {
        Random random = new Random();
        public int Width { get; private set; }
        public string[,] AField { get; private set; }
        public List<WallObject> WList = new List<WallObject>();
        public List<HealthObject> HList = new List<HealthObject>();
        public List<PowerObject> PList = new List<PowerObject>();
        public List<Person> EList = new List<Person>();
        public Field(int width)
        {
            Width = width;
            AField = new string[Width, Width];
            for (int i = 0; i < Width; i++)
            {
                for (int j = 0; j < Width; j++)
                {
                    AField[i, j] = " ";
                    int PlaceObject = 0;
                    for (int p = 0; p < 10000; p++) // 10 000 omdat anders de objecten voor de velden hetzelfde blijven daar het proces zo snel is dat het dezelfde seed heeft
                    {
                        PlaceObject = random.Next(0, 100);
                    }
                    if (PlaceObject == 50)
                    {
                        HealthObject H = new HealthObject(5, j , i);
                        HList.Add(H);
                        AField[i, j] = H.DisplayString;
                    }
                    if (PlaceObject == 30)
                    {
                        WallObject W = new WallObject(j, i);
                        WList.Add(W);
                        AField[i, j] = W.DisplayString;
                    }
                    if (PlaceObject == 20)
                    {
                        PowerObject P = new PowerObject(2, j, i);
                        PList.Add(P);
                        AField[i, j] = P.DisplayString;
                    }
                    if (PlaceObject == 80)
                    {
                        Person Enemy = new Person(j, i, 5, 2);
                        EList.Add(Enemy);
                        AField[i, j] = "X";
                    }
                    AField[0, j] = "_";
                    AField[width - 1, j] = "_";
                }
                AField[i, 0] = "|";
                AField[i, Width - 1] = "|";
            }
        }

        public void DisplayField(Dictionary<int, Field> Map, int Hor, int Vert)
        {
            int[] TempLoc = new int[2];
            for (int i = Vert - 1; i <= Vert + 1; i++)
            {
                TempLoc[0] = i;
                for (int a = 0; a < Width; a++)
                {
                    for (int j = Hor - 1; j <= Hor + 1; j++)
                    {
                        TempLoc[1] = j;
                        int TempCoords = GetHash(TempLoc);
                        for (int b = 0; b < Width; b++)
                        {
                            Console.Write(Convert.ToString(Map[TempCoords].AField[a, b]) + " ");
                        }
                    }
                    Console.WriteLine();
                }
            }
        }
        public void ErasePerson(Person person)
        {
            AField[person.Y, person.X] = ".";
        }

        public void PlacePerson(Person person)
        {
            foreach (HealthObject H in HList)
            {
                if (H.X == person.X && H.Y == person.Y)
                {
                    person.Health(H);
                }
            }
            foreach (PowerObject P in PList)
            {
                if (P.X == person.X && P.Y == person.Y)
                {
                    person.Power(P);
                }
            }
            AField[person.Y, person.X] = "O";
        }

        public static int GetHash(int[] obj) // om de hashwaarde te verkrijgen
        {
            int result = 17;
            for (int i = 0; i < obj.Length; i++)
            {
                unchecked
                {
                    result = result * 23 + obj[i];
                }
            }
            return result;
        }
    }
}