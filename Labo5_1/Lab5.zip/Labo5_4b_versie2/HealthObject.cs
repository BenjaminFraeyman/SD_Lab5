﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo5_4b_versie2
{
    class HealthObject
    {
        public string DisplayString { get; }
        public int HP { get; private set; }
        public int X { get; private set; }
        public int Y { get; private set; }

        public HealthObject(int hp, int x, int y)
        {
            DisplayString = "H";
            HP = hp;
            X = x;
            Y = y;
        }
        public override string ToString()
        {
            return DisplayString;
        }
    }
}