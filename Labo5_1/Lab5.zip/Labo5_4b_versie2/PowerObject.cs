﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo5_4b_versie2
{
    class PowerObject
    {
        public string DisplayString { get; }
        public int PP { get; private set; }
        public int X { get; private set; }
        public int Y { get; private set; }

        public PowerObject(int pp, int x, int y)
        {
            DisplayString = "P";
            PP = pp;
            X = x;
            Y = y;
        }
        public override string ToString()
        {
            return DisplayString;
        }
    }
}