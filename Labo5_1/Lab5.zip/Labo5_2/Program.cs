﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// benodigde tijd : 30minuten
namespace Labo3_3
{
    enum Hoofdmenu { Nieuw = 1, Gooi = 2, Stoppen = 3 };
    enum DiceType { NormalDice = 1, Magicdice = 2, Supermagicdice = 3 };   
    public class Program
    {

        public static void Main()
        {
            // default waardes // worden tijdens het uitvoeren van het programma toch uitgevoerd
            NormalDice dice = new NormalDice(6);
            Boolean Continue = true;
            int Throw = 0;
            int worpaantal = 0;
            int totaalworp = 0;
            // --------------

            while (Continue) // stoppen enkel door keuze Stoppen
            {
                Console.WriteLine("1: Nieuwe dobbelsteen");
                Console.WriteLine("2: Werpen");
                Console.WriteLine("3: Stoppen");
                int Keuze1 = Convert.ToInt32(Console.ReadLine());
                if (Keuze1 == (int)Hoofdmenu.Nieuw) // nieuw spel starten
                {
                    Console.WriteLine("Aantal vlakken?");
                    int Vlakken = Convert.ToInt32(Console.ReadLine());
                    dice = new NormalDice(Vlakken);       
                }

                if (Keuze1 == (int)Hoofdmenu.Gooi) // keuze gooi werd gemaakt
                {
                    Console.WriteLine("Aantal worpen?");
                    int worpaantall = Convert.ToInt32(Console.ReadLine());
                    totaalworp = worpaantal + worpaantall;
                    worpaantal = worpaantall;
                    for (int i = 0; i < worpaantal; i++)
                    {  
                        Throw = dice.ThrowDice();
                        dice.AddWorp(Throw);
                    }
                    
                    for (int i = 0; i < dice.Worpen.Length; i++)
                    {
                        double percent = Convert.ToDouble(dice.Worpen[i])/ totaalworp;
                        Console.WriteLine("Percentage van worp {0} = {1}%", i+1, percent*100);
                    }
                    Console.WriteLine("Worpaantal: {0}",totaalworp);
                }

                if (Keuze1 == (int)Hoofdmenu.Stoppen) // keuze stoppen werd gemaakt
                { Continue = false; }
                Console.WriteLine();
            }
        }
    }
}