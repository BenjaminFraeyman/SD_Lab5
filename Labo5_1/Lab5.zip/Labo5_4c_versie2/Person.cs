﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo5_4c_versie2
{
    class Person
    {
        public int X { get; private set; }
        public int Y { get; private set; }
        public int HP { get; private set; }
        public int PP { get; private set; }

        public Person(int x, int y, int hp, int pp)
        {
            X = x;
            Y = y;
            HP = hp;
            PP = pp;
        }

        public void Flag()
        {
            HP = 0;
        }
        public void Attacked(Person Enemy)
        {
            HP = HP - Enemy.PP;
            Enemy.HP = Enemy.HP - PP;
            Console.WriteLine("!!Attacked!! Hp = " + HP);
        }
        public void Health(HealthObject H)
        {
            HP = HP + H.HP;
            Console.WriteLine("Health Obtained: Hp = " + HP);
        }
        public void Power(PowerObject P)
        {
            PP = PP + P.PP;
            Console.WriteLine("Power Obtained: Pp = " + PP);
        }

        public void MovePerson(int dir, Field field)
        {
            int Tx = X;
            int Ty = Y;
            if (dir == 4) //left
            {
                X = X - 1;
            }
            if (dir == 8) //up
            {
                Y = Y - 1;
            }
            if (dir == 6) //right
            {
                X = X + 1;
            }
            if (dir == 2) //Down
            {
                Y = Y + 1;
            }
            
            foreach (WallObject Wall in field.WList)
            {
                if (X == Wall.X && Y == Wall.Y)
                {
                    X = Tx;
                    Y = Ty;
                }
            }
            foreach (Person enemy in field.EList)
            {
                if (X == enemy.X && Y == enemy.Y)
                {
                    Attacked(enemy);
                    if (enemy.HP > 0)
                    {
                        X = Tx;
                        Y = Ty;
                    }
                }
            }
        }
        public void SwitchField(int dir)
        {
            if (dir == 4) //left
            {
                X = 9;
            }
            if (dir == 8) //up
            {
                Y = 9;
            }
            if (dir == 6) //right
            {
                X = 0;
            }
            if (dir == 2) //Down
            {
                Y = 0;
            }
        }
    }
}