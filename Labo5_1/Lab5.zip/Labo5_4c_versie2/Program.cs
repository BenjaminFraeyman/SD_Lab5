﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// benodigde tijd: 20min
namespace Labo5_4c_versie2
{
    class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            int Choice = 0; // keuze van richting
            Dictionary<int, Field> Map = new Dictionary<int, Field>();
            string[] dir = new string[] { "8: Up", "2: Down", "4: Left", "6: Right", "0: Quit" }; // lijst van mogelijke richtingen
            int size = 10; // grootte van het veld
            Person Player = new Person(1, 1, 1, 1);
            Field field = new Field(size); // mainfield
            int[] Location = new int[2];
            int Coords = GetHash(Location);
            Field Tempfield = new Field(1); // tempfield
            int[] TempLoc = new int[2];
            int TempCoords = GetHash(TempLoc);
            Field Flagfield = new Field(size); // flagfield
            int Hor = 0;
            int Vert = 0;
            int[] FlagLoc = new int[2];
            int FlagCoords = GetHash(FlagLoc);
            Boolean Running = true;
            int Death = 1;
            while (Running)
            {
                if (Death == -1)
                {
                    Console.Clear();
                    Console.WriteLine("GAME OVER - Restart? (1: Yes, 2: No)");
                    while (!int.TryParse(Console.ReadLine(), out Death) || !(Death == 1) && !(Death == 2)) // om foute input te voorkomen
                    {
                        Console.WriteLine("Invalid input!");
                    }
                    if (Death == 2) // quit
                    {
                        Running = false;
                    }
                }
                if (Death == 1)
                {
                    Console.Clear();
                    Map = new Dictionary<int, Field>();
                    Player = new Person(size / 2, size / 2, 10, 2);
                    field = new Field(size); // mainfield
                    Location = new int[2] { 0, 0 };
                    field.PlacePerson(Player);
                    Coords = GetHash(Location);
                    Map.Add(Coords, field);
                    TempLoc = new int[2];
                    TempCoords = GetHash(TempLoc);
                    Tempfield = new Field(size); // tempfield
                    Flagfield = new Field(size); // flagfield
                    Flagfield.Placeflag();
                    Hor = 0;
                    Vert = 0;
                    FlagLoc = new int[2] { Hor = random.Next(-5, 5), Vert = random.Next(-5, 5) };
                    Console.WriteLine("Controle:");
                    Console.WriteLine("Vlag geplaatst op:" + Hor + " Verticaal, " + Vert + " Horizontaal");
                    Console.WriteLine("(-Verticaal = Naar Boven, +Verticaal = naar beneden, -Horizontaal = Links, +Horizontaal = rechts)");
                    Console.ReadLine();
                    FlagCoords = GetHash(FlagLoc);
                    Map.Add(FlagCoords, Flagfield);
                    Vert = 0;
                    Hor = 0;
                }

                while (Player.HP > 0)
                {
                    for (int i = Vert - 1; i <= Vert + 1; i++)
                    {
                        TempLoc[0] = i;
                        for (int j = Hor - 1; j <= Hor + 1; j++)
                        {
                            TempLoc[1] = j;
                            TempCoords = GetHash(TempLoc);
                            if (!Map.ContainsKey(TempCoords))
                            {
                                Tempfield = new Field(10);
                                Map.Add(TempCoords, Tempfield);
                            }
                        }
                    }
                    field.DisplayField(Map, Hor, Vert);
                    Console.WriteLine("What direction?");
                    foreach (string q in dir) // mogelijke keuzes
                    { Console.WriteLine(q); }
                    while (!int.TryParse(Console.ReadLine(), out Choice) || !(Choice == 0) && !(Choice == 4) && !(Choice == 2) && !(Choice == 8) && !(Choice == 6)) // om foute input te voorkomen
                    {
                        Console.WriteLine("Invalid input!");
                    }
                    if (Choice == 0) // quit
                    {
                        Running = false;
                    }
                    Console.Clear(); // opkuisen van console
                    field.ErasePerson(Player);
                    Player.MovePerson(Choice, field); // ventje verplaatsen naar locatie indien mogelijk
                    if (Player.X < 0)
                    {
                        Hor = Hor - 1;
                        Player.SwitchField(Choice);
                    }
                    if (Player.Y < 0)
                    {
                        Vert = Vert - 1;
                        Player.SwitchField(Choice);
                    }
                    if (Player.X == field.Width)
                    {
                        Hor = Hor + 1;
                        Player.SwitchField(Choice);
                    }

                    if (Player.Y == field.Width)
                    {
                        Vert = Vert + 1;
                        Player.SwitchField(Choice);
                    }
                    TempLoc[0] = Vert;
                    TempLoc[1] = Hor;
                    TempCoords = GetHash(TempLoc);
                    field = Map[TempCoords];
                    field.PlacePerson(Player);
                }
                Death = -1;

            }
        }

        public static int GetHash(int[] obj) // om de hashwaarde te verkrijgen
        {
            int result = 17;
            for (int i = 0; i < obj.Length; i++)
            {
                unchecked
                {
                    result = result * 23 + obj[i];
                }
            }
            return result;
        }
    }
}