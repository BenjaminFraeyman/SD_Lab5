﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo5_4a_versie2
{
    class Field
    {
        Random random = new Random();
        public int Width { get; private set; }
        public string[,] AField { get; private set; }

        public Field(int width)
        {
            Width = width;
            AField = new string[Width, Width];
            for (int i = 0; i < Width; i++)
            {
                for (int j = 0; j < Width - 1; j++)
                {
                    AField[i, j] = " ";
                    AField[0, j] = "_";
                }
                AField[i, Width - 1] = "|";
            }
        }

        public void DisplayField()
        {
            int count = 0;
            foreach (string i in AField)
            {
                Console.Write("{0}", i);
                count++;
                if (count == Width)
                {
                    Console.WriteLine();
                    count = 0;
                }
            }
        }

        public void ErasePerson(Person person)
        {
            AField[person.Y, person.X] = ".";
        }

        public void PlacePerson(Person person) 
        {
            AField[person.Y, person.X] = "x";
        }
    }
}