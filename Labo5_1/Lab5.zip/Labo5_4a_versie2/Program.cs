﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// benodigde tijd: 5h (compleet herwerkt na het labo, nu met dictionary ipv array)
namespace Labo5_4a_versie2
{
    class Program
    {
        static void Main(string[] args)
        {
            int Choice = 0; // keuze van richting
            Dictionary<int, Field> Map = new Dictionary<int, Field>();
            string[] dir = new string[] { "8: Up", "2: Down", "4: Left", "6: Right", "0: Quit" }; // lijst van mogelijke richtingen
            int n = 0;
            Person Player = new Person(5, 5); // je speler
            Field field = new Field(10); // mainfield
            int[] C = new int[2] { n, n }; // coords van speler
            field.PlacePerson(Player); // speler plaatsen
            int Coord = GetHash(C); // hash van coords nemen
            Map.Add(Coord, field); // aan dict toevoegen
            int[] Temp = new int[2]; 
            int TempCoord = GetHash(Temp); // coords van tempveld in hash plaatsen
            Field tempfield = new Field(10); // mainfield
            Boolean running = true; 
            int Vert = 0;
            int Hor = 0;

            while (running)
            {
                for (int i = Vert - 1; i <= Vert + 1; i++)
                {
                    Temp[0] = i;
                    for (int j = Hor - 1; j <= Hor + 1; j++)
                    {
                        Temp[1] = j;
                        TempCoord = GetHash(Temp);
                        if (!Map.ContainsKey(TempCoord)) // als het veld nog niet bestaat, maak een nieuwe aan
                        {
                            tempfield = new Field(10); // mainfield
                            Map.Add(TempCoord, tempfield);
                        }
                    }
                }
                for (int i = Vert - 1; i <= Vert + 1; i++) // horizontaal lijn per lijn afprinten, dan nadat alle eerste lijnen zijn geprint een enter en dan zelfde voor 2de lijn
                {
                    Temp[0] = i;
                    for (int a = 0; a < field.Width; a++)
                    {
                        for (int j = Hor - 1; j <= Hor + 1; j++)
                        {
                            Temp[1] = j;
                            TempCoord = GetHash(Temp);
                            for (int b = 0; b < field.Width; b++)
                            {
                                Console.Write(Convert.ToString(Map[TempCoord].AField[a, b]) + " ");
                            }
                        }
                        Console.WriteLine();
                    }
                }
                Console.WriteLine("What direction?");
                foreach (string q in dir) // mogelijke keuzes
                { Console.WriteLine(q); }
                while (!int.TryParse(Console.ReadLine(), out Choice) || !(Choice == 0) && !(Choice == 4) && !(Choice == 2) && !(Choice == 8) && !(Choice == 6)) // om foute input te voorkomen
                {
                    Console.WriteLine("Invalid input!");
                }
                if (Choice == 0) // quit
                {
                    running = false;
                }
                Console.Clear(); // opkuisen van console
                field.ErasePerson(Player);
                Player.MovePerson(Choice); // ventje verplaatsen naar locatie indien mogelijk
                if (Player.X < 0) // als je van veld verandert in deze richting
                {
                    Hor = Hor - 1;
                    Temp[0] = Vert;
                    Temp[1] = Hor;
                    TempCoord = GetHash(Temp);
                    field = Map[TempCoord];
                    Player.SwitchField(Choice);
                }
                if (Player.Y < 0) // als je van veld verandert in deze richting
                {
                    Vert = Vert - 1;
                    Temp[0] = Vert;
                    Temp[1] = Hor;
                    TempCoord = GetHash(Temp);
                    field = Map[TempCoord];
                    Player.SwitchField(Choice);
                }
                if (Player.X == field.Width) // als je van veld verandert in deze richting
                {
                    Hor = Hor + 1;
                    Temp[0] = Vert;
                    Temp[1] = Hor;
                    TempCoord = GetHash(Temp);
                    field = Map[TempCoord];
                    Player.SwitchField(Choice);
                }

                if (Player.Y == field.Width) // als je van veld verandert in deze richting
                {
                    Vert = Vert + 1;
                    Temp[0] = Vert;
                    Temp[1] = Hor;
                    TempCoord = GetHash(Temp);
                    field = Map[TempCoord];
                    Player.SwitchField(Choice);
                }
                Temp[0] = Vert;
                Temp[1] = Hor;
                field.PlacePerson(Player);
            }
        }
        public static int GetHash(int[] obj) // hash maken van de waardes
        {
            int result = 17;
            for (int i = 0; i < obj.Length; i++)
            {
                unchecked
                {
                    result = result * 23 + obj[i];
                }
            }
            return result;
        }
    }
}