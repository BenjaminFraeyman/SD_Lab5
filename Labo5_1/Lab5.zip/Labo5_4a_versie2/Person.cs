﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labo5_4a_versie2
{
    class Person
    {
        public int X { get; private set; }
        public int Y { get; private set; }
        public Person(int x, int y)
        {
            X = x;
            Y = y;
        }

        public void MovePerson(int dir)
        {
            if (dir == 4) //left
            {
                X = X - 1;
            }
            if (dir == 8) //up
            {
                Y = Y - 1;
            }
            if (dir == 6) //right
            {
                X = X + 1;
            }
            if (dir == 2) //Down
            {
                Y = Y + 1;
            }
        }
        public void SwitchField(int dir)
        {
            if (dir == 4) //left
            {
               X = 9;
            }
            if (dir == 8) //up
            {
                Y = 9;
            }
            if (dir == 6) //right
            {
                X = 0;
            }
            if (dir == 2) //Down
            {
                Y = 0;
            }
        }
    }
}
